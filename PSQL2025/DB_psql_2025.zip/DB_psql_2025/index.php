<?php

spl_autoload_register( function ($class){
    if(file_exists(ROOT_PATH . '/../controllers/' . $class . '.php')){
        require_once(ROOT_PATH . '/../controllers/' . $class . '.php');
    }
});


require_once 'login.php';

$page = $_GET['p'] ?? 'dashboard';
?>