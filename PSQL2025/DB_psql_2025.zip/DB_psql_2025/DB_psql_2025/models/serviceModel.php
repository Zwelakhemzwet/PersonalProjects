<?php

require_once 'Database.php';
require_once 'ModelInterface.php';

class MastersModel extends Database
implements DBInterface {

    public function getAll(){
        $stmt = $this->pdo->query("SELECT * FROM services");
        return $stmt->fetchAll;
    }

    public function getServiceById($id){
        $stmt = $this->pdo->prepare("SELECT * FROM services WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function createService($data){
        $stmt = $this->pdo->prepare("INSERT INTO services (name, cost_our, cost_foreign) VALUES (?, ?, ?)");
        return $stmt->execute([
            $data['name'],
            $data['cost_our'],
            $data['cost_foreign']
        ]);
    }

    public function deleteService($id){
        $stmt = $this->pdo->preapare("DELETE FROM services WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function updateService($id, $data){
        $stmt = $this->pdo->prepare("UPDATE services SET name = ?, cost_our = ?, cost_foreign = ? WHERE id = ?");
        return $stmt->execute([
            $data['name'],
            $data['cost_our'],
            $data['cost_foreign'],
            $id]
        );
    }
}
?>