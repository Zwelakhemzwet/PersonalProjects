<?php
define('ROOT_PATH', __DIR__);

$database = file('../config/database.txt');

class Database{
    public $pdo;
    function __construct(){
        try{
            $this->pdo = new PDO('pqsl:/host=' . $database['DB_HOST'] .';dbname=' . $database['DB_NAME'],
                            $database['DB_USER'], $database['DB_PASS'],
                        [
                            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                        ]);
        } catch (PDOException $e){
            error_log('database connection error: ' . $e->getMessage());
        }
    }
}
?>