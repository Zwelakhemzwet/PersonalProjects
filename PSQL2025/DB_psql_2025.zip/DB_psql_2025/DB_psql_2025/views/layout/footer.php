    </body>
    <script>
    </script>
    <footer>
        <div class="footer-sec footer-sec1">
        </div>
        <div class="footer-sec footer-sec2">
        </div>
        <div class="footer-sec footer-sec3">
        </div>
    </footer>
</html>
