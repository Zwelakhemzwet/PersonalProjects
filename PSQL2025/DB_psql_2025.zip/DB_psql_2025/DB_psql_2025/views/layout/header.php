<!DOCTYPE html>
<html>
    <head>
        <title>Admin</title>
        <script src="https://kit.fontawesome.com/6f0be4257f.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="<?= PAGE_ROOT?>/css/header.css"/>
    </head>
    <body>
        <div class="nav-panel">
            <a class="nav-link" href="/?m=dashboard">
                <i class="fa-solid fa-gauge-high"></i>
                <span>Dashboard</span>
            </a>
            <a class="nav-link" href="/?m=cars&action=list">
                <i class="fa-solid fa-car"></i>
                <span>cars</span>
            </a>
            <a class="nav-link" href="/?m=masters&action=list">
                <i class="fa fa-"></i>
                <span>masters</span>
            </a>
            <a class="nav-link" href="/?m=services&action=list">
                <i class="fa fa-"></i>
                <span>services</span>
            </a>
            <a class="nav-link" href="/?m=works&action=list">
                <i class="fa-solid fa-book"></i>
                <span>works</span>
            </a>
        </div>
    