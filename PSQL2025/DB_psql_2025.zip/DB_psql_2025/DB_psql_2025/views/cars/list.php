<?php
require_once 'views/layout/header.php';
?>
<a class="add-button" href="/?m=cars&action=create">
    <i class="fa-solid fa-plus"></i>
    <span>Добавить новую машину</span>
</a>
<table id="cars-table">
    <caption>Машины</caption>
    <thead>
        <th>id</th>
        <th>number(номер)</th>
        <th>color(цвет)</th>
        <th>mark(марка)</th>
        <th>is_foreign(национальность)</th>
    </thead>
    <tbody>

<?php
foreach($cars as $car){
?>
    <tr>
        <td><?= $car['id']?></td>
        <td><?= $car['num']?></td>
        <td><?= $car['color']?></td>
        <td><?= $car['mark']?></td>
        <td><?= $car['is_foreign']?></td>
    </tr>
<?php }?>
    </tbody>
</table>

<?php require_once 'views/layout/footer.php' ?>
