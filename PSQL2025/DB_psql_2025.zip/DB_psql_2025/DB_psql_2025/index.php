<?php
define('ROOT_PATH', __DIR__);
define('PAGE_ROOT', 'DB_PSQL_2025');
require_once ROOT_PATH . '/views/layout/header.php';

spl_autoload_register( function ($class){
    if(file_exists(ROOT_PATH . '/controllers/' . $class . '.php')){
        require_once(ROOT_PATH . '/controllers/' . $class . '.php');
    } elseif (file_exists(ROOT_PATH . '/models/' . $class . '.php')){
        require_once ROOT_PATH . '/models/' . $class . '.php';
    }
});


require_once 'login.php';

$model = $_GET['m'] ?? 'dashboard';
$action = $_GET['action'] ?? 'list';

switch($model){
    case "cars":
        $carcontroller = new CarController();
        switch($action){
            case 'list':
                $carcontroller->listAllCars();
                break;
            case 'edit':
                $carcontroller->editCar();
                break;
            case 'delete':
                $carcontroller->deleteCar();
                break;
            default:
                $carcontroller->listAllCars();
                break;
        }
        break;
    default:
        $dashboard = new Dashboard();
}

?>