#!/bin/bash

mdkir views/masters
touch views/masters/list.php
touch views/masters/edit.php
touch views/masters/create.php

mdkir views/cars
touch views/masters/list.php
touch views/masters/edit.php
touch views/masters/create.php

mdkir views/services
touch views/masters/list.php
touch views/masters/edit.php
touch views/masters/create.php


mdkir views/works
touch views/masters/list.php
touch views/masters/edit.php
touch views/masters/create.php