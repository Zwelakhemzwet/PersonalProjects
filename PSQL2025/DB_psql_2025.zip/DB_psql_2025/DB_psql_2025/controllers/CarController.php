<?php
require_once ROOT_PATH . '/models/CarModel.php';
$carmodel = new CarModel();
?>
<?

class CarController{
    public function listAllCars(){
        $cars = $carmodel->getAll();
        require_once ROOT_PATH . '/views/cars/list.php';
    }

    public function editCar(){
        if(!isset($_POST['car_id'])){
            return;
        }

    }
}

?>