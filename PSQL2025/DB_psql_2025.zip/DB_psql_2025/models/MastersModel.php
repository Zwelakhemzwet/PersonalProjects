<?php

require_once 'Database.php';
require_once 'ModelInterface.php';

class MastersModel extends Database
implements DBInterface {

    public function getAll(){
        $stmt = $this->pdo->query("SELECT * FROM masters");
        return $stmt->fetchAll;
    }

    public function getMasterById($id){
        $stmt = $this->pdo->prepare("SELECT * FROM masters WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function createMaster($data){
        $stmt = $this->pdo->prepare("INSERT INTO masters (name) VALUES (?, ?)");
        return $stmt->execute([
            $data['name']
        ]);
    }

    public function deleteMaster($id){
        $stmt = $this->pdo->preapare("DELETE FROM masters WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function updateMaster($id, $data){
        $stmt = $this->pdo->prepare("UPDATE masters SET name = ? WHERE id = ?");
        return $stmt->execute([$data['name'], $id]);
    }
}
?>