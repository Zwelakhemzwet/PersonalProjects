<?php
interface DBInterface {
    function getAll();
}
?>