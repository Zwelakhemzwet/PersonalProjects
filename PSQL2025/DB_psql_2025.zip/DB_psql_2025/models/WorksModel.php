<?php

require_once 'Database.php';
require_once 'ModelInterface.php';

class MastersModel extends Database
implements DBInterface {

    public function getAll(){
        $stmt = $this->pdo->query("SELECT w.date_work, m.name, c.id AS car_id, s.id AS service_id
        FROM works w
        LEFT JOIN masters m ON m.id = w.master_id
        LEFT JOIN cars c ON c.id = w.car_id
        LEFT JOIN services s ON s.id = w.service_id");
        return $stmt->fetchAll;
    }

    public function getWorkById($id){
        $stmt = $this->pdo->prepare("SELECT * FROM works WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function createWork($data){
        $stmt = $this->pdo->prepare("INSERT INTO works (date_work, master_id, service_id, car_id) VALUES (?, ?, ?, ?)");
        return $stmt->execute([
            $data['date_work'],
            $data['master_id'],
            $data['service_id'],
            $data['car_id']
        ]);
    }

    public function deleteWork($id){
        $stmt = $this->pdo->preapare("DELETE FROM works WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function updateWork($id, $data){
        $stmt = $this->pdo->prepare("UPDATE works SET date_work = ?, master_id = ?, service_id = ?, car_id = ? WHERE id = ?");
        return $stmt->execute([
            $data['date_work'],
            $data['master_id'],
            $data['service_id'],
            $data['car_id'],
            $id
        ]);
    }

    public function getWorkByMaster($id){
        $stmt = $this->pdo->prepare("");
    }
}
?>