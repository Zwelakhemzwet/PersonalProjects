<?php
if(isset($_GET[session_name()])){
    session_id($_GET[session_name()]);
}
session_start();

// if(!isset($_SESSION['uid'])){
//     header('Location: /login?m=login');
// }
require_once ROOT_PATH . '/config/loginconfig.php';
require_once ROOT_PATH . '/config/functions.php';
$uid = $_SESSION['uid'];
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Admin</title>
        <script src="https://kit.fontawesome.com/6f0be4257f.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="css/footer.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/header.css"/>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="nav-panel">
            <a class="nav-link" href="<?= url_with_sesid('/?m=dashboard&action=list')?>&uid=<?= $uid?>">
                <i class="fa-solid fa-gauge-high"></i>
                <span>Dashboard</span>
            </a>
            <a class="nav-link" href="<?= url_with_sesid('/?m=cars&action=list')?>&uid=<?= $uid?>">
                <i class="fa-solid fa-car"></i>
                <span>cars</span>
            </a>
            <a class="nav-link" href="<?= url_with_sesid('/?m=masters&action=list')?>&uid=<?= $uid?>">
                <i class="fa-solid fa-toolbox"></i>
                <span>masters</span>
            </a>
            <a class="nav-link" href="<?= url_with_sesid('/?m=services&action=list')?>&uid=<?= $uid?>">
                <i class="fa-solid fa-wrench"></i>
                <span>services</span>
            </a>
            <a class="nav-link" href="<?= url_with_sesid('/?m=works&action=list')?>&uid=<?= $uid?>">
                <i class="fa-solid fa-book"></i>
                <span>works</span>
            </a>
            <a class="nav-link" href="/?m=login" id="log-out-link">
                <i class="fa-solid fa-right-from-bracket logout"></i>
                <span>выйти</span>
            </a>
            <a class="nav-link usr-prfl" >
                <i class="fa-solid fa-user"></i>
                <span><?= $uid?></span><br/>
                <span><?= $_SESSION['role']?></span>
            </a>
        </div>
    