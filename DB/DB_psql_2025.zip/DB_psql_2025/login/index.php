<?php
session_start();
define('ROOT_PATH', __DIR__ . '/..');
define('PAGE_ROOT', 'DB_PSQL_2025');
//require_once ROOT_PATH . '/views/layout/scripts.php';

spl_autoload_register(function ($class) {
    if (file_exists(ROOT_PATH . '/controllers/' . $class . '.php')) {
        require_once ROOT_PATH .'/controllers/' . $class . '.php';
    } elseif (file_exists(ROOT_PATH . '/models/' . $class . '.php')) {
        require_once ROOT_PATH . '/models/' . $class . '.php';
    }
});

//echo "main index: curl " . $_SESSION['current-pg_url'] . '<br/>URI: ' . $_SERVER['REQUEST_URI'] .
//'<br/>uid: ' . $_GET['uid'] . '<br/>';
$admincontroller = new AdminController();

$model = $_GET['m'] ?? 'login';

switch($model){
    case 'login':
        $admincontroller->userLogin(substr($_SERVER['REQUEST_URI'], strpos($_SERVER['REQUEST_URI'],'/') + 1));
        break;
    case 'register':
        $admincontroller->userRegistration();
        break;
    default:
        $admincontroller->userLogin(substr($_SERVER['REQUEST_URI'], strpos($_SERVER['REQUEST_URI'],'/') + 1));
        break;
}

?>