<?php
require_once ROOT_PATH . '/views/layout/header.php';
?>

<div class="content">
    <div class="info-card">
        <h2 class="itm-name"><?= $service['name']?></h2>
        <ul>
            <li class="item-attr">
                <span class="attr-name">отечественная стоимость</span>
                <span><?= $service['cost_our']?>руб</span>
            </li>
            <li class="item-attr">
                <span class="attr-name">зарубежная стоимость</span>
                <span><?= $service['cost_foreign']?>руб</span>
            </li>
        </ul>
        <button type="button" class="bg-bl pad-10 bdr-8" onclick="window.history.back()">НАЗАД</button>
    </div>
</div>