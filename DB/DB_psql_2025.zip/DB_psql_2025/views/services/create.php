<?php
require_once ROOT_PATH . '/views/layout/header.php';
?>

<div class="content">
    <div class="sec-info">
        <h1 class="no-marg">Управление услугами</h1>
    </div>
        <form class="create-form" method="POST">
            <div class="field">
                <label for="name" >название услуги*</label>
                <input id="name" class="form-control" type="text" name="name" required/>
            </div>
            <div class="field">
                <label for="cost_our" >отечественная стоимость*</label>
                <input id="cost_our" class="form-control" type="number" min="0" name="cost_our" required/>
            </div>
            <div class="field">
                <label for="cost_foreign" >зарубежнная стоимость*</label>
                <input id="cost_foreign" class="form-control" type="number" min="0" name="cost_foreign" required/>
            </div>
            <div class="form-controls">
                <button class="bdr-8 bg-bl">создать</button>
                <button class="bdr-8 bg-rd" type="button" onclick="window.location.href='<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=services&action=list'">отменить</button>
            </div>
        </form>
        
</div>