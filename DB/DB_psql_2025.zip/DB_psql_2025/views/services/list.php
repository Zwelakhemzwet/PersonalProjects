<?php
require_once ROOT_PATH . '/views/layout/header.php';
?>
<div class="content">
    <?php if(isset($_GET['success'])){
        ?>
    <div class="alert alert-msg <?= $_GET['success'] == 'true' ? "alert-success": "alert-fail"?>">
        <?=
        $_GET['success'] == 'true' ? "операция выполнена успешно" : "не удалось выполнить операцию";
        ?>
    </div>
            <?php
    }    
    ?>
    <?php if($_SESSION['role'] == 'admin'){ ?>
        <div class="add-link">
            <a class="add-btn bdr-8 pad-10 w-500" href="<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=services&action=create">
                <i class="fa-solid fa-plus"></i>
                <span><strong>Добавить новую услугу</strong></span>
            </a>
        </div>
    <?php }?>

<table id="cars-table">
    <caption>услуги</caption>
    <thead>
        <tr>
            <th>id</th>
            <th>name(название)</th>
            <th>cost_our<br/>(отечественная стоимость)</th>
            <th>cost_foreign<br/>(зарубежнная стоимость)</th>
            <th></th>
        </tr>
    </thead>
    <tbody>

<?php
foreach($services as $service){
?>
    <tr>
        <td><?= $service['id']?></td>
        <td><?= $service['name']?></td>
        <td><?= $service['cost_our']?></td>
        <td><?= $service['cost_foreign']?></td>
        <?php if($_SESSION['role'] == 'admin'){ ?>
            <td class="edit-controls">
                <a class="edit-btn" href="<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=services&action=edit&id=<?= $service['id']?>">
                    <i class="fa-regular fa-pen-to-square"></i>
                </a>
                <div class="delete-btn btn-danger" data-href="<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=services&action=delete&id=<?= $service['id']?>">
                    <i class="fa-solid fa-trash"></i>
                </div>
            </td>
        <?php }?>
        
    </tr>
<?php }?>
    </tbody>
</table>
</div>
<?php require_once ROOT_PATH . '/views/layout/footer.php' ?>
