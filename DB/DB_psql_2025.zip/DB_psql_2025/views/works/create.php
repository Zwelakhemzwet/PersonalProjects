<?php
require_once ROOT_PATH . '/views/layout/header.php';
?>

<div class="content">
    <div class="sec-info">
        <h1 class="no-marg">Управление работами</h1>
    </div>
        <form class="create-form" method="POST">
            <div class="field">
                <label for="date_work" >Дата оказания услуги*</label>
                <input id="date_work" class="form-control" type="date" name="date_work" required/>
            </div>
            <div class="field">
                <label for="master_id" >Мастер*</label>
                <select id="master_id" class="form-control" name="master_id">
                    <?php foreach($masters as $master) {?>
                    <option value="<?=$master['id']?>"><?= $master['name']?></option>
                    <?php }?>
                </select>
            </div>
            <div class="field">
                <label for="car_id">номер машины*</label>
                <select id="car_id" class="form-control" type="text" name="car_id" required>
                    <?php foreach($cars as $car) {?>
                    <option value="<?=$car['id']?>"><?= $car['num']?></option>
                    <?php }?>
                </select>
            </div>
            <div class="field">
                <label for="service_id" >услуга*</label>
                <select id="service_id" class="form-control" type="text" name="service_id" required>
                    <?php foreach($services as $service) {?>
                    <option value="<?=$service['id']?>"><?=$service['name']?></option>
                    <?php }?>
                </select>
            </div>
            <div class="form-controls">
                <button class="bdr-8 bg-bl">создать</button>
                <button class="bdr-8 bg-rd" type="button" onclick="window.location.href='<?=PAGE_ROOT . '/my?uid=' . $uid . '&m=works&action=list'?>'">отмена</button>
            </div>
        </form>
        
</div>