<?php
require_once ROOT_PATH . '/views/layout/header.php';

?>
<div class="content">
    <?php if(isset($_GET['success'])){
        ?>
    <div class="alert alert-msg <?= $_GET['success'] == 'true' ? "alert-success": "alert-fail"?>">
        <?=
        $_GET['success'] == 'true' ? "операция выполнена успешно" :
        "<span>не удалось выполнить операцию. возможные причины:</span>
        <ul>
            <li>мастер уже выполнил работу на сегодня</li>
            <li>указана дату в прошлом</li>
            <li>редактирование: изменение даты на более чем 1 день (restrict_work_date_change)</li>
        </ul>";
        ?>
    </div>
            <?php
    }    
    ?>
    <div class="user_functions">
        <div>
            <h5>фильтрация по дату</h5>
            <div class="works form-div">
                <div class="field works">
                    <span>показать конечную дату</span>
                    <input type="checkbox" id='show_date_end' name="show_date_end"/>
                </div>
                <div class="field rw works">
                    <span><strong>С</strong></span>
                    <input type="date" id='date_start' name="date_start"/>
                </div>
                <div class="field rw" id='date_end_fld'>
                    <span><strong>ДО</strong></span>
                    <input type="date" id='date_end' name="date_end"/>
                </div>
            </div>
        </div>
    </div>
    <?php if($_SESSION['role'] == 'admin'){ ?>
        <div class="add-link">
            <a class="add-btn bdr-8 pad-10 w-500" href="<?= PAGE_ROOT?>/my?uid=<?= $uid ?>&m=works&action=create">
                <i class="fa-solid fa-plus"></i>
                <span><strong>Добавить новую работу</strong></span>
            </a>
        </div>
    <?php }?>
<div class="stats costs">
    <table class="stats-table">
        <caption>стоимости(руб)</caption>
        <thead>
            <tr>
                <th>отечественные машины</th>
                <th>зарубежные машины</th>
            </tr>
        </thead>
        <tbody id='stats-list'>
            <tr>
                <td><?= $totalCosts['local']?>
                <td><?= $totalCosts['foreign']?>
            </tr>
        </tbody>
    </table>
</div>
    
<table id="works-table">
    <caption>
        работы
    </caption>
    <thead>
        <tr>
            <th>id</th>
            <th>date_work</th>
            <th>master_id<br/>(id мастер)</th>
            <th>car_id</th>
            <th>service_id</th>
            <th></th>
        </tr>
    </thead>
    <tbody id="works-list">

<?php
foreach($works as $work){
?>
    <tr>
        <td><?= $work['id']?></td>
        <td><?= $work['date_work']?></td>
        <td class="wrapped">
            <?= $work['master_id']?>
            <span class="hidden-wrap master-name bdr-8" style="display: none;position: absolute">
                <?= $this->mastersmodel->getMasterById($work['master_id'])['name']?>
            <span>
            <!-- <a class="info-link" href="/?m=masters&action=info&id=<?= $work['master_id']?>">
                <?= $work['master_id']?>
            </a> -->
        </td>
        <td>
            <a class="info-link" href="<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=cars&action=info&id=<?= $work['car_id']?>">
                <?= $work['car_id']?>
            </a>
        </td>
        <td>
            <a class="info-link" href="<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=services&action=info&id=<?= $work['service_id']?>">
                <?= $work['service_id']?>
            </a>
        </td>
        <?php if($_SESSION['role'] == 'admin'){ ?>
            <td class="edit-controls">
                <a class="edit-btn" href="<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=works&action=edit&id=<?= $work['id']?>">
                    <i class="fa-regular fa-pen-to-square"></i>
                </a>
                <div class="delete-btn btn-danger" data-href="<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=works&action=delete&id=<?= $work['id']?>">
                    <i class="fa-solid fa-trash"></i>
                </div>
            </td>
        <?php }?>
        
    </tr>
<?php }?>
    </tbody>
</table>
</div>
<?php require_once ROOT_PATH . '/views/layout/footer.php' ?>
