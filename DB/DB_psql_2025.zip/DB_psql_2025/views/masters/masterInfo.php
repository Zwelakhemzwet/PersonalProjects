<?php
require_once 'views/layout/header.php';
?>

<div class="content">
    <div class="info-card">
        <h2 class="itm-name"><?= $master['name']?></h2>
        <ul>
            <li class="item-attr">
                <span class="attr-name">имя мастера</span>
                <span><?= $master['name']?></span>
            </li>
        </ul>
        <button type="button" class="bg-bl pad-10 bdr-8" onclick="window.history.back()">НАЗАД</button>
    </div>
</div>