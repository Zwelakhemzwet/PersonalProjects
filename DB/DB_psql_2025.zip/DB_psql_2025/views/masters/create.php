<?php
require_once ROOT_PATH . '/views/layout/header.php';
?>

<div class="content">
    <div class="sec-info">
        <h1 class="no-marg">Управление мастерами</h1>
    </div>
        <form class="create-form" method="POST">
            <div class="field">
                <label for="name" >имя мастера*</label>
                <input id="name" class="form-control" type="text" name="name" required/>
            </div>
            
            <div class="form-controls">
                <button class="bdr-8 bg-bl">создать</button>
                <button class="bdr-8 bg-rd" type="button" onclick="window.location.href='<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=masters&action=list'">отменить</button>
            </div>
        </form>
        
</div>