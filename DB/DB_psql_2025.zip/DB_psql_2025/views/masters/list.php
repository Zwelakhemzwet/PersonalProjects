<?php
require_once ROOT_PATH . '/views/layout/header.php';
?>
<div class="content">
    <?php if(isset($_GET['success'])){
        ?>
    <div class="alert alert-msg <?= $_GET['success'] == 'true' ? "alert-success": "alert-fail"?>">
        <?=
        $_GET['success'] == 'true' ? "операция выполнена успешно" : "<span>не удалось выполнить операцию. возможные причины:</span>
        <ul>
            <li>имена мастеров совпадают</li>
        </ul>";
        ?>
    </div>
            <?php
    }    
    ?>
    <?php if($_SESSION['role'] == 'admin'){ ?>
        <div class="add-link">
            <a class="add-btn bdr-8 pad-10 w-500" href="<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=masters&action=create">
                <i class="fa-solid fa-plus"></i>
                <span><strong>Добавить нового мастера</strong></span>
            </a>
        </div>
    <?php }?>
<div clss="stats">
    <table class="stats-table">
        <caption>продуктивные мастера</caption>
        <thead>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>число<br/>уникальных машин</th>
                <th>количество<br/>выполнимых работы</th>
                <th>период времени</th>
            </tr>
        </thead>
        <tbody>
            <?php if($bestFive) {foreach($bestFive as $master){?>
                <tr>
                    <td><?= $master['master_id']?></td>
                    <td><?= $master['master_name']?></td>
                    <td><?=$master['unique_cars_count']?></td>
                    <td><?=$master['total_works_count']?></td>
                    <td><?=$master['month_period']?></td>
                </tr>
            <?php } }?>
        </tbody>
    </table>
</div>
    
<table id="masters-table">
    <caption>Мастеры</caption>
    <thead>
        <tr>
            <th>id</th>
            <th>name</th>
            <th></th>
        </tr>
    </thead>
    <tbody>

<?php
foreach($masters as $master){
?>
    <tr>
        <td><?= $master['id']?></td>
        <td><?= $master['name']?></td>
        <?php if($_SESSION['role'] == 'admin'){ ?>
            <td class="edit-controls">
                <a class="edit-btn" href="<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=masters&action=edit&id=<?= $master['id']?>">
                    <i class="fa-regular fa-pen-to-square"></i>
                </a>
                <div class="delete-btn btn-danger" data-href="<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=masters&action=delete&id=<?= $master['id']?>">
                    <i class="fa-solid fa-trash"></i>
                </div>
            </td>
        <?php }?>
        
    </tr>
<?php }?>
    </tbody>
</table>
</div>
<?php require_once ROOT_PATH . '/views/layout/footer.php' ?>
