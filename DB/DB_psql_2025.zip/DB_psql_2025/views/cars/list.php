<?php
require_once ROOT_PATH . '/views/layout/header.php';
//echo $_SESSION['role'] . '<br/>';
?>
<div class="content">
    <?php if(isset($_GET['success'])){
        ?>
    <div class="alert alert-msg <?= $_GET['success'] == 'true' ? "alert-success": "alert-fail"?>">
        <?=
        $_GET['success'] == 'true' ? "операция выполнена успешно" : "
        <span>не удалось выполнить операцию. возможные причины:</span>
        <ul>
            <li>добавлена машина с уже существующим номером</li>
            <li>удаление: на машину выполнена работа(restrict_car_delete_on_work_conn)</li>
            <li>редактирование: машина с уже существующим номером</li>
        </ul>";
        ?>
    </div>
            <?php
    }    
    ?>
    <?php if($_SESSION['role'] == 'admin'){ ?>
        <div class="add-link">
            <a class="add-btn bdr-8 pad-10 w-500" href="<?= PAGE_ROOT?>/my?uid=<?= $uid?>&m=cars&action=create">
                <i class="fa-solid fa-plus"></i>
                <span><strong>Добавить новую машину</strong></span>
            </a>
        </div>
    <?php }?>
    
<table id="cars-table">
    <caption>Машины</caption>
    <thead>
        <tr>
            <th>id</th>
            <th>number(номер)</th>
            <th>color(цвет)</th>
            <th>mark(марка)</th>
            <th>is_foreign<br/>(зарубежнная)</th>
            <th></th>
        </tr>
    </thead>
    <tbody>

<?php
foreach($cars as $car){
?>
    <tr>
        <td><?= $car['id']?></td>
        <td><?= $car['num']?></td>
        <td><?= $car['color']?></td>
        <td><?= $car['mark']?></td>
        <td><?= $car['is_foreign'] == 1 ? "да" : "нет" ?></td>
        <?php if($_SESSION['role'] == 'admin'){ ?>
            <td class="edit-controls">
                <a class="edit-btn" href="<?= PAGE_ROOT ?>/?uid=<?= $uid?>&m=cars&action=edit&id=<?= $car['id']?>">
                    <i class="fa-regular fa-pen-to-square"></i>
                </a>
                <div class="delete-btn btn-danger" data-href="<?= PAGE_ROOT ?>/my?uid=<?= $uid?>&m=cars&action=delete&id=<?= $car['id']?>">
                    <i class="fa-solid fa-trash"></i>
                </div>
            </td>
        <?php }?>
        
    </tr>
<?php }?>
    </tbody>
</table>
</div>
<?php require_once ROOT_PATH . '/views/layout/footer.php' ?>
