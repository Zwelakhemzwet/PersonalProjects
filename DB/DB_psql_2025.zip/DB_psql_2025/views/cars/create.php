<?php
require_once ROOT_PATH . '/views/layout/header.php';
?>

<div class="content">
    <div class="sec-info">
        <h1 class="no-marg">Управление машинами</h1>
    </div>
        <form class="create-form" method="POST">
            <div class="field">
                <label for="car_num" >номер машины*</label>
                <input id="car_num" class="form-control" type="text" name="num" required/>
            </div>
            <div class="field">
                <label for="car_color" >цвет*</label>
                <input id="car_color" class="form-control" type="text" name="color" required/>
            </div>
            <div class="field">
                <label for="car_mark" >марка*</label>
                <input id="car_mark" class="form-control" type="text" name="mark" required/>
            </div>
            <div class="field">
                <label for="car_foreign" >национальность*</label>
                <select id="car_foreign" class="form-control" name="is_foreign" required>
                    <option value="0">отечественная</option>
                    <option value="1">зарубежнная</option>
                </select>
            </div>
            <div class="form-controls">
                <button class="bdr-8 bg-bl">создать</button>
                <button class="bdr-8 bg-rd" type="button"
                onclick="window.location.href='<?=PAGE_ROOT?>/my?uid=<?= $uid?>&m=cars&action=list'">отмена</button>
            </div>
        </form>
        
</div>