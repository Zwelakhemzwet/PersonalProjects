<?php
require_once ROOT_PATH . '/views/layout/header.php';
?>

<div class="content">
    <div class="info-card">
        <h2 class="itm-name">Машина</h2>
        <ul>
            <li class="item-attr">
                <span class="attr-name">Номер</span>
                <span>:<?= $car['num']?></span>
            </li>
            <li class="item-attr">
                <span class="attr-name">марка</span>
                <span>:<?= $car['mark']?></span>
            </li>
            <li class="item-attr">
                <span class="attr-name">Цвет</span>
                <span>:<?= $car['color']?></span>
            </li>
            <li class="item-attr">
                <span class="attr-name">национальность</span>
                <span>:<?= $car['is_foreign'] == 1 ? "зарубежная" : "отечественная" ?></span>
            </li>
        </ul>
        <button type="button" class="bg-bl pad-10 bdr-8" onclick="window.history.back()">НАЗАД</button>
    </div>
</div>