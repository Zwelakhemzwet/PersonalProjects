<?php
session_start();
require_once ROOT_PATH . '/views/layout/header.php';
?>

<div class="content">
    <div class="sec-info">
        <h1 class="no-marg">редактировать машину</h1>
    </div>
        <form class="create-form" method="POST">
            <div class="field">
                <label for="car_num" >номер машины*</label>
                <input id="car_num" class="form-control" type="text"
                name="num" value="<?= $current_car['num']?>" required/>
            </div>
            <div class="field">
                <label for="car_color" >цвет*</label>
                <input id="car_color" class="form-control" type="text"
                name="color" value="<?= $current_car['color']?>" required/>
            </div>
            <div class="field">
                <label for="car_mark" >марка*</label>
                <input id="car_mark" class="form-control" type="text"
                name="mark" value="<?= $current_car['mark']?>" required/>
            </div>
            <div class="field">
                <label for="car_foreign" >национальность*</label>
                <select id="car_foreign" class="form-control"
                name="is_foreign" required>
                    <option value="1" <?= $current_car['is_foreign'] == 0 ? 'selected' : '' ?>>отечественная</option>
                    <option value="0" <?= $current_car['is_foreign'] == 1 ? 'selected' : '' ?>>зарубежнная</option>
                </select>
            </div>
            <div class="form-controls">
                <button class="bdr-8 bg-bl">сохранить</button>
                <button class="bdr-8 bg-rd" type="button" onclick="window.location.href='<?= PAGE_ROOT ?>/?m=cars&action=list&uid=<?= $uid?>'">отмена</button>
            </div>
        </form>
        
</div>