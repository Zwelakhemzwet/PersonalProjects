<?php
require_once 'layout/header.php';
//echo "session role " . $_SESSION['role'] . '<br/>uid ' . $_SESSION['uif'] . '<br/>';
?>

<div class="content">
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= $stats['cars_count'] ?? 0 ?></h4>
                            <p>машины</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fa-solid fa-car"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="/my/?uid=<?= $uid?>&m=cars" class="text-white">Управление</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= $stats['masters_count'] ?? 0 ?></h4>
                            <p>мастеры</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fa-solid fa-toolbox"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="/my/?uid=<?= $uid?>&m=masters" class="text-white">Управление</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= $stats['services_count'] ?? 0 ?></h4>
                            <p>услуги</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fa-solid fa-wrench"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="?uid=<?= $uid?>&m=services" class="text-white">Управление</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= $stats['works_count'] ?? 0 ?></h4>
                            <p>работы</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fa-solid fa-book"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="?uid=<?= $uid?>&m=works" class="text-white">Управление</a>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row mt-4">
        <?php if($_SESSION['role'] == 'admin'){ ?>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Быстрые действия</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="?uid=<?= $uid?>&m=cars&action=create" class="btn btn-outline-primary">
                            <i class="fas fa-plus"></i> Добавить машины
                        </a>
                        <a href="?uid=<?= $uid?>&m=masters&action=create" class="btn btn-outline-success">
                            <i class="fas fa-plus"></i> Добавить мастеров
                        </a>
                        <a href="?uid=<?= $uid?>&m=services&action=create" class="btn btn-outline-warning">
                            <i class="fas fa-plus"></i> Создать услуги
                        </a>
                        <a href="?uid=<?= $uid?>&m=works&action=create" class="btn btn-outline-info">
                            <i class="fas fa-plus"></i> Добавить работы
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php }?>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Последние активности</h5>
                </div>
                <div class="card-body">
                    <p class="text-muted">Здесь будет отображаться история действий...</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once ROOT_PATH . '/views/layout/footer.php'; ?>