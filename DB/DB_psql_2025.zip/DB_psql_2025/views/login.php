<?php
require_once ROOT_PATH . '/views/layout/regFormHeader.php';?>

<div class="content">
    <h3 style='margin: 10px;'><?= $form_name == "r" ? "РЕГИСТРАЦИЯ" : "ЛОГИН" ?></h3>
    <div class="log-links">
        <a href="<?= PAGE_ROOT?>/?m=login" class="bdr-8">
            <i class="fa-solid fa-arrow-right-to-bracket"></i>
            <span>логин</span>
        </a>
        <a href="<?= PAGE_ROOT?>/?m=register" class="bdr-8">
            <i class="fa-solid fa-user-plus"></i>
            <span>релистрация</span>
        </a>
    </div>
    <form class="form reg-form" id="login-form" method="POST">
        <div class="field">
            <label for="login">Логин</lable>
            <input class="form-control" type="text" id="login" name="login"></input>
        </div>
        <div class="field">
            <label for="password" >Пароль</lable>
            <div class="pswrd-field">
                <input class="form-control" type="password" id="password" name="password"
                style="border: none"></input>
                <i class="fa-solid fa-eye eye-icon"></i>
            </div>
        </div>
        <div class="field" id="role-checkbox">
            <input type="checkbox" name="show-role"/>
            <label for="password" > show role</lable>
        </div>
        <div class="field" id="role-field">
            <label for="role" >role</lable>
            <select class="form-control" type="te" id="role" name="role"
                style="border: none">
                <option value="guest" selected>guest</option>
                <option value="admin">admin</option>
            </select>
        </div>
        
        <div class="form-controls">
            <button class="bg-bl bdr-8">ДАЛЕЕ</button>
            <!-- <button class="bg-rd bdr-8" type="button" onclick="">ОТМЕНА</button> -->
        </div>
    </form>
</div>

<?php require_once ROOT_PATH . '/views/layout/footer.php' ?>;
