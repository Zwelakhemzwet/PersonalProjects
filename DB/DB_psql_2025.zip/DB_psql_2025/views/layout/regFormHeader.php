
<!DOCTYPE html>
<html>
    <head>
        <title>User Authentication</title>
        <script src="https://kit.fontawesome.com/6f0be4257f.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="<?= PAGE_ROOT . '/css/footer.css'?>"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="<?= PAGE_ROOT . '/css/header.css'?>"/>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body>
        
    