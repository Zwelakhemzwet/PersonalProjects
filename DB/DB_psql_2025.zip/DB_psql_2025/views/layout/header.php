<?php
require_once ROOT_PATH . '/config/loginconfig.php';
require_once ROOT_PATH . '/config/functions.php';
$uid = $_SESSION['uid'];
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Admin</title>
        <script src="https://kit.fontawesome.com/6f0be4257f.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="/DB_psql_2025/css/footer.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="/DB_psql_2025/css/header.css"/>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="nav-panel">
            <a class="nav-link" href="<?= url_with_sesid(PAGE_ROOT . '/my?m=dashboard&action=list')?>">
                <i class="fa-solid fa-gauge-high"></i>
                <span>Dashboard</span>
            </a>
            <a class="nav-link" href="<?= url_with_sesid(PAGE_ROOT . '/my?m=cars&action=list')?>">
                <i class="fa-solid fa-car"></i>
                <span>cars</span>
            </a>
            <a class="nav-link" href="<?= url_with_sesid(PAGE_ROOT . '/my?m=masters&action=list')?>">
                <i class="fa-solid fa-toolbox"></i>
                <span>masters</span>
            </a>
            <a class="nav-link" href="<?= url_with_sesid(PAGE_ROOT . '/my?m=services&action=list')?>">
                <i class="fa-solid fa-wrench"></i>
                <span>services</span>
            </a>
            <a class="nav-link" href="<?= url_with_sesid(PAGE_ROOT . '/my?m=works&action=list')?>">
                <i class="fa-solid fa-book"></i>
                <span>works</span>
            </a>
            <a class="nav-link" href="<?= PAGE_ROOT ?>/?m=login" id="log-out-link">
                <i class="fa-solid fa-right-from-bracket logout"></i>
                <span>выйти</span>
            </a>
            <a class="nav-link usr-prfl" >
                <i class="fa-solid fa-user"></i>
                <span><?= $uid?></span><br/>
                <span><?= $_SESSION['role']?></span>
            </a>
        </div>
    