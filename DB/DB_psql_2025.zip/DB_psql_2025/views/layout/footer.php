
    </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => {
                let alerts = document.querySelectorAll('.alert');
                if(alerts.length > 0){
                    alerts.forEach( alert => {
                        let bsAlert = new bootstrap.Alert(alert);
                        bsAlert.close();
                    })
                }
            }, 5000);

            handelMasterInfoHover();

            let eyeIcon = document.querySelector(".eye-icon");
            if(eyeIcon){
                eyeIcon.addEventListener("click", function(event){
                    let passField = event.currentTarget.parentElement.querySelector("input");
                    if(!passField){
                        return;
                    }
                    if(event.currentTarget.classList.contains('fa-eye')){
                        event.currentTarget.classList.remove('fa-eye');
                        event.currentTarget.classList.add('fa-eye-slash');
                        passField.type = 'text';
                        
                    } else {
                        event.currentTarget.classList.remove('fa-eye-slash');
                        event.currentTarget.classList.add('fa-eye');
                        passField.type = 'password';
                    }
                });
            }
            handleRoleCheck();
            handleWorksFilterByDate();
            handleLogOut();
        });
        let deleteBtns = document.querySelectorAll(".btn-danger");
        if(deleteBtns.length > 0){
            deleteBtns.forEach( btn => {
                btn.addEventListener("click", () => {
                    let proceed = window.confirm('Вы уверены вы хотите удалить данную запись из базы данных?');
                    let a = document.createElement('a');
                    a.href = btn.dataset.href;
                    if(proceed){
                        a.click();
                        //console.log(btn.dataset.href);
                        return;
                        //window.location.href = btn.dataset.href;
                    }
                })
            })
        } else {
            console.log("btns not found");
        }
        function handelMasterInfoHover(){
            let wrappedCtns = document.querySelectorAll(".wrapped");
            if(wrappedCtns){
                wrappedCtns.forEach(ctn => {
                    let itm = ctn.querySelector(".hidden-wrap");
                    let timer = null;
                    ctn.addEventListener('mouseenter', function(event){
                        if(itm){
                            clearTimeout(timer);
                            itm.style.display = 'inline';
                            itm.style.maxHeight = `${itm.scrollHeight}px`;
                        }
                    });
                    ctn.addEventListener('mouseleave', function(event){
                        if(itm){
                            itm.style.maxHeight = `0`;
                            timer = setTimeout(()=>{
                                itm.style.display = 'none';
                            }, 300);
                            
                        }
                    });
                });
                
            }
        }
        function handleRoleCheck(){
            let role_checkbox = document.querySelector("input[name='show-role']");
            if(role_checkbox){
                let role_field = document.querySelector('#role-field');
                if(!role_field){
                    console.log("role field not found");
                    return;
                }
                role_checkbox.addEventListener('change', () =>{
                    role_field.style.display = role_checkbox.checked ? 'flex' : 'none';
                })
                
            }
        }
        function handleWorksFilterByDate(){
            let showDateEndCheck = document.querySelector('#show_date_end');
            const dateEndField = document.querySelector('#date_end_fld');

            if(showDateEndCheck && dateEndField){
                showDateEndCheck.addEventListener('change', function(e){
                    dateEndField.style.display = showDateEndCheck.checked ? 'flex' : 'none';
                })
            }
            const dateStartInp = document.querySelector('.works #date_start');
            const dateEndInp = document.querySelector('.works #date_end');
            if(dateStartInp && dateEndInp){

                dateStartInp.addEventListener('change', async function(e){
                    let response = await fetch(`<?= PAGE_ROOT ?>/models/dbReader.php?`,
                        {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                m: 'works',
                                ds: e.currentTarget.value
                            })
                        }
                    );
                    try{
                        let data = await response.json();
                        renderWorksList(data.works);
                        renderCosts(data.costs);
                    }catch(error){
                        console.log(error).message;
                    }
                    
                });

                dateEndInp.addEventListener('change', async function(e){
                    let response;
                    if(!dateStartInp.value){
                        response = await fetch(`<?= PAGE_ROOT ?>/models/dbReader.php`,
                            {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    m: 'works',
                                    de: e.currentTarget.value
                                })
                            }
                        );
                    } else {
                        response = await fetch(`<?= PAGE_ROOT ?>/models/dbReader.php`,
                            {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    m: 'works',
                                    ds: dateStartInp.value,
                                    de: e.currentTarget.value
                                })
                            }
                        );
                    }
                    try{
                        let data = await response.json();
                        renderWorksList(data.works);
                        renderCosts(data.costs);
                    }catch(error){
                        console.log(error.message);
                    }
                })
            }

            function renderCosts(costs){
                let costslist = '';
                const listDiv = document.querySelector('#stats-list');
                console.log(costs.local, costs.foreign);
                try{
                    costslist += `<tr>
                        <td>${costs.local}</td>
                        <td>${costs.foreign}</td>
                    </tr>`;
                } catch(error){
                    console.log(error);
                    return;
                }
                listDiv.innerHTML = costslist;
            }

            function renderWorksList(works){
                let worksList = '';
                const listDiv = document.querySelector('#works-list');
                try{
                    Array.from(works).forEach(work => {
                        worksList += `<tr>
                            <td>${work['id']}</td>
                            <td>${work['date_work']}</td>
                            <td class="wrapped">
                                ${work['master_id']}
                                <span class="hidden-wrap master-name bdr-8" style="display: none;position: absolute">
                                    ${work['master_name']}
                                <span>
                                <!-- <a class="info-link" href="/?m=masters&action=info&id=${work['master_id']}">
                                    ${work['master_id']}
                                </a> -->
                            </td>
                            <td>
                                <a class="info-link" href="/?uid=<?= $uid?>&m=cars&action=info&id=${work['car_id']}">
                                    ${work['car_id']}
                                </a>
                            </td>
                            <td>
                                <a class="info-link" href="/?uid=<?= $uid?>&m=services&action=info&id=${work['service_id']}">
                                    ${work['service_id']}
                                </a>
                            </td>
                            <?php if($_SESSION['role'] == 'admin'){ ?>
                                <td class="edit-controls">
                                    <a class="edit-btn" href="/?uid=<?= $uid?>&m=works&action=edit&id=${work['id']}">
                                        <i class="fa-regular fa-pen-to-square"></i>
                                    </a>
                                    <div class="delete-btn btn-danger" data-href="/?uid=<?= $uid?>&m=works&action=delete&id=${work['id']}">
                                        <i class="fa-solid fa-trash"></i>
                                    </div>
                                </td>
                            <?php }?>
                            
                        </tr>`;
                    });
                    if(works.length > 0){
                        listDiv.innerHTML = worksList;
                        handelMasterInfoHover();
                    } else {
                        listDiv.innerHTML = "<h2>нет записей</h2>";
                    }
                } catch(error){
                    console.log("error rendering works list: " + error);
                    return;
                }
            }
        }
        function handleLogOut(){
            let logOutLink = document.querySelector('#log-out-link');
            if(logOutLink){
                logOutLink.addEventListener('click', async ()=>{
                    let response = await fetch('<?= PAGE_ROOT ?>/config/logout.php');
                    let data = await response.json();
                })
            }
        }
    </script>
</html>
