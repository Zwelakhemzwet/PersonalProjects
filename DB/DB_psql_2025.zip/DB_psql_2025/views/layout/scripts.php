
<script>
    fetch('/config/save_url.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url: window.location.href })
    })
</script>