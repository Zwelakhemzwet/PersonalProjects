<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'zvelake');
define('DB_NAME', 'zvelakedb');
define('DB_PASS', 'zvelak3@psql2025');
define('DB_PORT', '5432');
define('ADMIN_LOGIN', ['login' => 'admin', 'password'=> 'zvelakeadmin']);
?>