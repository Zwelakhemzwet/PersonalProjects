<?php
session_start();
$input = json_decode(file_get_contents('php://input'), true);

if(isset($input['url'])){
    $_SESSION['current-pg_url'] = $input['url'];
}

echo $_SESSION['current-pg_url'];
session_write_close();
?>