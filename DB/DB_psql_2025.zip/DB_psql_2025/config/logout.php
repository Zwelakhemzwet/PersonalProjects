<?php
session_start();
$olduid = $_SESSION['uid'];
$oldrole = $_SESSION['role'];

if(isset($_SESSION['uid'])){
    unset($_SESSION['uid']);
}

if(isset($_SESSION['role'])){
    unset($_SESSION['role']);
}

session_write_close();
header('Content-Type: application/json');
echo json_encode(['success' => 'true',
    'uid' => $_SESSION['uid'],
    'role' => $_SESSION['role'],
    'olduid' => $olduid,
    'oldrole' => $oldrole]
);
exit();
?>