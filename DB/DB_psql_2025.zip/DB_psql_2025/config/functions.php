
<?php
function url_with_sesid($url){
    if(session_status() === PHP_SESSION_ACTIVE){
        $seperator = strpos($url, '?') == false ? '?' : '&';
        return $url . $seperator . session_name() . '=' . session_id();
    }
    return $url;
}
?>