<?php
session_start();
if(!isset($_SESSION['uid']) || !isset($_SESSION['role'])){
    header('Location: ' . PAGE_ROOT . '/?m=login');
    exit();
}
?>