<?php
$database = file(ROOT_PATH . '/config/database.txt');
require_once ROOT_PATH . '/config/database.php';

class Database{
    protected $pdo;
    function __construct(){
        try{
            $this->pdo = new PDO('pgsql:host=' . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME
                            ,DB_USER, DB_PASS,
                        [
                            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                        ]);
        } catch (PDOException $e){
            error_log('database connection error: ' . $e->getMessage());
        }
    }
}
?>