<?php

require_once 'Database.php';
require_once 'ModelInterface.php';

class MastersModel extends Database
implements DBInterface {

    public function getAll(){
        $stmt = $this->pdo->query("SELECT * FROM masters");
        return $stmt->fetchAll();
    }

    public function getMasterById($id){
        $stmt = $this->pdo->prepare("SELECT * FROM masters WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function createMaster($data){
        try{
            $stmt = $this->pdo->prepare("INSERT INTO masters (name) VALUES (?)");
            return $stmt->execute([
                $data['name']
            ]);
        } catch(PDOException $e){
            return false;
        }
        
    }

    public function deleteMaster($id){
        try{
            $stmt = $this->pdo->prepare("DELETE FROM masters WHERE id = ?");
            return $stmt->execute([$id]);
        } catch (PDOException $e){
            error_log("MastersModel Error: " . $e->getMessage());
            return false;
        }
        return false;
    }

    public function updateMaster($id, $data){
        try{
            $stmt = $this->pdo->prepare("UPDATE masters SET name = ? WHERE id = ?");
            return $stmt->execute([$data['name'], $id]);
        } catch(PDOException $e){
            error_log("MastersModel Error: " . $e->getMessage());
            return false;
        }
        return false;
    }

    public function getTopMastersByMonth($month_year = null) {
        $sql = "SELECT * FROM get_top_masters_by_unique_cars(?)";
        $stmt = $this->pdo->prepare($sql);
        
        $stmt->bindValue(1, $month_year, $month_year ? PDO::PARAM_STR : PDO::PARAM_NULL);
        $stmt->execute();
        
        $results = $stmt->fetchAll();
        
        return [
            'month_period' => $results[0]['month_period'] ?? date('Y-m'),
            'masters' => $results
        ];
    }
}
?>