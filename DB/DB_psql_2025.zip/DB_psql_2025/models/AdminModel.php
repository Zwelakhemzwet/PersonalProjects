<?php
require_once 'Database.php';

class AdminModel extends Database {
    public function grantLogin($data){
        try{
            $stmt = $this->pdo->prepare("SELECT COUNT(*)
            FROM user_login_stat ls
            LEFT JOIN users us ON us.id = ls.user_id
            WHERE us.user_num = ? AND ls.log_end > CURRENT_TIMESTAMP
            ");

            if($stmt->execute([
                '' . $data['login']
            ])){
                $result = $stmt->fetchColumn();
                if($result > 0){                    
                    return ['access' => 'granted', 'uid' => $data['login']];
                }
            }

            $stmt = $this->pdo->prepare("SELECT id,
            password_hash, user_num
            FROM users WHERE name = ? LIMIT 1");

            $stmt->execute([
                $data['login']
            ]);
            $result = $stmt->fetch();

            if($result == false){
                return ["access" => "denied", "message" => $result];
            }

            if(password_verify($data['password'], $result['password_hash'])){
                $stmt = $this->pdo->prepare("INSERT INTO user_login_stat (user_id)
                VALUES (?)");
                if($stmt->execute([$result['id']])){
                    return ['access' => 'granted', 'uid' => $result['user_num']];   
                }

                return ['access' => 'denied', 'message' => 'server_error'];
            }

            return ['access' => 'denied', 'message' => 'wrong_password'];
        } catch (PDOException $e){
            return ["access" => "denied", "message" => "system-error: " . $e->getMessage()];
        }
    }

    public function registerUser($data){
        try{
            $stmt = $this->pdo->prepare("INSERT INTO users (name, password_hash, role, user_num)
            VALUES (?, ?, ?, ?)");
            $unique_num = uniqid();
            return $stmt->execute([
                $data['name'],
                $data['password_hash'],
                $data['role'],
                '' . $unique_num
            ]);
        } catch(PDOException $e){
            return false;
        }
    }
    public function getStat(){
        $stmt = $this->pdo->query("SELECT COUNT(*) AS cars_count FROM cars");
        $cars_count = $stmt->fetch()['cars_count'];

        $stmt = $this->pdo->query("SELECT COUNT(*) AS masters_count FROM masters");
        $masters_count = $stmt->fetch()['masters_count'];

        $stmt = $this->pdo->query("SELECT COUNT(*) AS works_count FROM works");
        $works_count = $stmt->fetch()['works_count'];

        $stmt = $this->pdo->query("SELECT COUNT(*) AS services_count FROM services");
        $services_count = $stmt->fetch()['services_count'];

        return ['cars_count' => $cars_count,
                'masters_count' => $masters_count,
                'works_count' => $works_count,
                'services_count' => $services_count];
    }

    public function grantAdminPriviledges($uid){
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM users WHERE user_num = ? AND role = 'admin'");
        $stmt->execute([ '' . $uid]);
        return $stmt->fetchColumn() > 0;
    }
}
?>