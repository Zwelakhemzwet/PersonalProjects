<?php
header("Content-Type: application/json; charset=utf-8");
define('ROOT_PATH', __DIR__ . '/..');
spl_autoload_register(function ($class) {
    if (file_exists(ROOT_PATH . '/controllers/' . $class . '.php')) {
        require_once ROOT_PATH .'/controllers/' . $class . '.php';
    } elseif (file_exists(ROOT_PATH . '/models/' . $class . '.php')) {
        require_once ROOT_PATH . '/models/' . $class . '.php';
    }
});

function cleanUtf8($data) {
    if (is_array($data)) {
        return array_map('cleanUtf8', $data);
    } elseif (is_string($data)) {
        return iconv('UTF-8', 'UTF-8//IGNORE', $data);
    }
    return $data;
}

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

$method = $_SERVER['REQUEST_METHOD'];
$data = [];

if($method == 'GET'){
    $data = $_GET;
} elseif($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $data = is_array($input) ? $input : $_POST;
}

if(!isset($data['m'])){
    echo json_encode(['reponse' => 'error', 'message' => 'model not specified']);
    exit();
}
$targetModel = $data['m'];
$response = [];

try{
    switch($targetModel){
        case 'works':
            $model = new WorksModel();
            if((isset($data['ds']) && !empty($data['ds'])) || (isset($data['de']) && !empty($data['de']))){
                // все работы в эти даты
                $works = $model->getWorkByDate($data['ds'] ?? null, $data['de'] ?? null);

                // стоимости в эти даты
                $costs = $model->getCostsUniversal($data['ds'] ?? null, $data['de'] ?? null);
                // стоимости без фильтрации
                $totalcosts = $model->getCostsUniversal();

                //header("Content-Type: application/json");
                $response = ['works' => $works, 'costs' => $costs, 'totalCosts' => $totalcosts];
            } else {
                $response = ['error' => 'ds not specified'];
            }
            
            break;
        default:
            $response = ['error' => 'unknown model: ' . $targetModel ];
            break;
    }
} catch(Exception $e){
    $response = ['error' => 'server error', 'message' => $e->getMessage()];
}

$cleanedData = cleanUtf8($response);
echo json_encode($cleanedData, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_IGNORE);
exit();
?>