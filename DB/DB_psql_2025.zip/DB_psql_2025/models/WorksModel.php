<?php

require_once 'Database.php';
require_once 'ModelInterface.php';

// w.id, w.date_work, m.name, c.id AS car_id, s.id AS service_id
//         FROM works w
//         LEFT JOIN masters m ON m.id = w.master_id
//         LEFT JOIN cars c ON c.id = w.car_id
//         LEFT JOIN services s ON s.id = w.service_id

class WorksModel extends Database
implements DBInterface {

    public function getAll(){
        $stmt = $this->pdo->query("SELECT * FROM works");
        return $stmt->fetchAll();
    }

    public function getWorkById($id){
        $stmt = $this->pdo->prepare("SELECT * FROM works WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function getWorkByDate($date_start, $date_end){
        try{
            $stmt = null;
            
            if($date_end && $date_start){

                if(!strtotime($date_start)){
                    return ["error" => 'invalid date format'];
                }
                
                if(!strtotime($date_end)){
                    return ["error" => 'invalid date format'];
                }
                $start_ts = strtotime($date_start);
                $end_ts = strtotime($date_end);

                if($end_ts < $start_ts){
                    return [ 'error' => 'end date', 'message' => 'date end cant be less than date start'];
                }

                $stmt = $this->pdo->prepare('SELECT w.*, m.name as master_name
                FROM works w
                LEFT JOIN masters m ON m.id = w.master_id
                WHERE date_work BETWEEN ? AND ?');
                $stmt->execute([$date_start, $date_end]);
            } elseif($date_start) {
                if(!strtotime($date_start)){
                    return ["error" => 'invalid date format'];
                }

                $stmt = $this->pdo->prepare('SELECT w.*, m.name as master_name
                FROM works w
                LEFT JOIN masters m ON m.id = w.master_id
                WHERE date_work = ?');

                $stmt->execute([$date_start]);
            } elseif($date_end) {
                if(!strtotime($date_end)){
                    return ["error" => 'invalid date format'];
                }

                $stmt = $this->pdo->prepare('SELECT w.*, m.name as master_name
                FROM works w
                LEFT JOIN masters m ON m.id = w.master_id
                WHERE date_work < ? OR date_work = ?');

                $stmt->execute([$date_end, $date_end]);
            }
            $result = $stmt->fetchAll();

            if(empty($result)){
                return ["error", "RESULT ERROR", 'message' => 'no records'];
            }
            return $result;
            
        } catch(PDOException $e){
            error_log("Database error: " . $e->getMessage());
            return ['error' => 'DatabaseError', 'message' => $e->getMessage()];
        }
        
    }

    public function createWork($data){
        try{
            $stmt = $this->pdo->prepare("INSERT INTO works (date_work, master_id, service_id, car_id) VALUES (?, ?, ?, ?)");
            return $stmt->execute([
                $data['date_work'],
                $data['master_id'],
                $data['service_id'],
                $data['car_id']
            ]);
        } catch (PDOException $e){
            return false;
        }
        
    }

    public function deleteWork($id){
        try{
            $stmt = $this->pdo->prepare("DELETE FROM works WHERE id = ?");
            return $stmt->execute([$id]);
        } catch(PDOException $e){
            error_log("WorksModel Error: " . $e->getMessage());
            return false;
        }
        return false;
    }

    public function updateWork($id, $data){
        try{
            $stmt = $this->pdo->prepare("UPDATE works SET date_work = ?, master_id = ?, service_id = ?, car_id = ? WHERE id = ?");
            return $stmt->execute([
                $data['date_work'],
                $data['master_id'],
                $data['service_id'],
                $data['car_id'],
                $id
            ]);
        } catch(PDOException $e){
            error_log("WorksModel Error: " . $e->getMessage());
            return false;
        }
        return false;
    }

    public function getWorkByMaster($id){
        $stmt = $this->pdo->prepare("");
    }

    public function getCostsByDate($date_start, $date_end) {
        $sql = "CALL total_service_costs_on_all_cars_dateFilt(?, ?, ?, ?)";
        $stmt = $this->pdo->prepare($sql);
        
        // Инициализируем переменные
        $total_local = 0;
        $total_foreign = 0;
        
        // Привязываем параметры
        $stmt->bindValue(3, $date_start, $date_start ? PDO::PARAM_STR : PDO::PARAM_NULL);
        $stmt->bindValue(4, $date_end, $date_end ? PDO::PARAM_STR : PDO::PARAM_NULL);
        $stmt->bindParam(1, $total_local, PDO::PARAM_INT);
        $stmt->bindParam(2, $total_foreign, PDO::PARAM_INT);
        
        $stmt->execute();
        
        // Явно преобразуем в int на случай NULL
        return [
            'local' => (int)$total_local,
            'foreign' => (int)$total_foreign,
            'date_start' => $date_start,
            'date_end' => $date_end
        ];
    }
    public function getCostsFlexibleFunction($date_start = null, $date_end = null) {
        $sql = "SELECT * FROM get_total_costs_by_date_fixed(?, ?)";
        $stmt = $this->pdo->prepare($sql);
        
        $stmt->bindValue(1, $date_start, $date_start ? PDO::PARAM_STR : PDO::PARAM_NULL);
        $stmt->bindValue(2, $date_end, $date_end ? PDO::PARAM_STR : PDO::PARAM_NULL);
        
        $stmt->execute();
        $result = $stmt->fetch();
        
        return [
            'local' => (int)$result['local_costs'],
            'foreign' => (int)$result['foreign_costs'],
            'date_start' => $date_start,
            'date_end' => $date_end
        ];
    }

    public function getAllCosts() {
        $sql = "CALL total_service_costs_on_all_cars(?, ?)";
        $stmt = $this->pdo->prepare($sql);
        
        $stmt->bindParam(1, $total_local, PDO::PARAM_INT, 10);
        $stmt->bindParam(2, $total_foreign, PDO::PARAM_INT, 10);
        
        $stmt->execute();
        
        return [
            'local' => $total_local,
            'foreign' => $total_foreign
        ];
    }

    public function getCostsUniversal($date_start = null, $date_end = null) {
        $sql = "SELECT * FROM get_total_costs_universal(?, ?)";
        $stmt = $this->pdo->prepare($sql);
        
        $stmt->bindValue(1, $date_start, $date_start ? PDO::PARAM_STR : PDO::PARAM_NULL);
        $stmt->bindValue(2, $date_end, $date_end ? PDO::PARAM_STR : PDO::PARAM_NULL);
        
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $period_info = "all_time";
        if ($date_start && $date_end) {
            $period_info = "range_{$date_start}_to_{$date_end}";
        } elseif ($date_start) {
            $period_info = "single_date_{$date_start}";
        } elseif ($date_end) {
            $period_info = "until_date_{$date_end}";
        }
        
        return [
            'local' => (int)$result['local_costs'],
            'foreign' => (int)$result['foreign_costs'],
            'date_start' => $date_start,
            'date_end' => $date_end,
            'period' => $period_info
        ];
    }

    public function getCostsByPeriodType($pdo, $period_type = 'all', $date_value = null) {
        switch ($period_type) {
            case 'single_date':
                return getCostsUniversal($pdo, $date_value, null);
            case 'until_date':
                return getCostsUniversal($pdo, null, $date_value);
            case 'range':
                if (is_array($date_value)) {
                    return getCostsUniversal($pdo, $date_value[0], $date_value[1]);
                }
                // Если не массив, используем как одинарную дату
                return getCostsUniversal($pdo, $date_value, null);
            case 'all':
            default:
                return getAllCosts($pdo);
        }
    }
    
}
?>