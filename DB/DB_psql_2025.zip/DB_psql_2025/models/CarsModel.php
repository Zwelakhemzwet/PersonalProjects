<?php
require_once 'Database.php';
require_once 'ModelInterface.php';

class CarsModel extends Database implements DBInterface{
    public function getAll(){
        $stmt = $this->pdo->query("SELECT * FROM cars");
        return $stmt->fetchAll();
    }

    public function getCarById($id){
        $stmt = $this->pdo->prepare("SELECT * FROM cars WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function createCar($data){
        try{
            $stmt = $this->pdo->prepare("INSERT INTO cars (num, color, mark, is_foreign)
            VALUES (?, ?, ?, ?)");
            return $stmt->execute([
                $data['num'],
                $data['color'],
                $data['mark'],
                $data['is_foreign']
            ]);
        } catch(PDOEXception $e){
            error_log("CarsModel error: " . $e->getMessage());
            return false;
        }
    }

    public function deleteCar($id){
        try{
            $stmt = $this->pdo->prepare("DELETE FROM cars WHERE id = ?");
            return $stmt->execute([$id]);
        } catch(PDOException $e){
            error_log("CarsMode Error: " . $e->getMessage());
            return false;
        }
        return false;
    }

    public function updateCar($id, $data){
        try{
            $stmt = $this->pdo->prepare("UPDATE cars SET num = ?, color = ?, mark = ?, is_foreign = ?
            WHERE id = ?");

            return $stmt->execute([
                $data['num'],
                $data['color'],
                $data['mark'],
                $data['is_foreign'],
                $id
            ]);
        } catch(PDOException $e){
            error_log("CarsMode Error: " . $e->getMessage());
            return false;
        }
        return false;
    }
}
?>