#!/bin/bash

touch views/services/list.php
touch views/services/edit.php
touch views/services/create.php


touch views/works/list.php
touch views/works/edit.php
touch views/works/create.php