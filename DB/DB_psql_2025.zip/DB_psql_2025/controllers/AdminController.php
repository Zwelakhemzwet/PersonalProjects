<?php
session_start();
require_once ROOT_PATH . '/models/AdminModel.php';


class AdminController {
    private $model;

    function __construct(){
        $this->model = new AdminModel();
    }

    public function userLogin($url){
        if($_POST){
            $response = $this->model->grantLogin($_POST);
            if($this->validate($response)){
                header("Location: " . PAGE_ROOT . '/my?uid=' . $response['uid'] . "&m=dashboard&action=list");
                exit();
            }
            
        } elseif (isset($_SESSION['uid']) && !empty($_SESSION['uid'])){
            
            $data = [
                    'login' => $_SESSION['uid'],
                    'password' => 'none'
                ];
            $response = $this->model->grantLogin($data);
            if($this->validate($response)){
                if($url){
                    //header('Location: /my?m=dashboard');
                    header("Location: " . PAGE_ROOT . '/my' . $url);
                    exit();
                }
                header("Location: " . PAGE_ROOT . "/my?uid=" . $response['uid'] . "&m=dashboard&action=list");
                exit();
            }
        }
        $form_name = "l";
        require_once ROOT_PATH . '/views/login.php';
    }

    private function validate($response){
        if($response['access'] == 'denied'){
            echo "" . $response['message'] . $_SESSION['uid'];
            if($response['message'] == 'unregistered'){
                //header("Location: /login?m=login");
                echo "" . $response['message'] . $_SESSION['uid'];
                exit();
            } elseif($response['message'] == 'wrong_password'){
                echo "<div class='alert alert-msg alert-fail' style='width: fit-content; margin: auto'>
                    не верный пароль
                </div>";
                return false;
            }
        } else {
            
            $_SESSION["uid"] = $response['uid'];
            $_SESSION['role'] = $this->model->grantAdminPriviledges($response['uid']) ? 'admin' : 'guest';
            session_write_close();
            return true;
        }
        return true;
    }

    public function userRegistration(){
        if($_POST){
            $data = [
                'name' => $_POST['login'],
                'password_hash' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                'role' => $_POST['role'] ?? 'guest'
            ];
            if($this->model->registerUser($data)){
                header("Location: ?m=login");
                exit();
            } else {
                ?>
                <div class="alert alert-msg alert-fail">
                   не удалось выполнить операцию
                </div>
                <?php
            }
        }
        $form_name = "r";
        require_once ROOT_PATH . '/views/login.php';
    }

    public function dashboard(){
        $stats = $this->model->getStat();
        require_once ROOT_PATH . '/views/dashboard.php';
    }
}
?>