<?php
require_once ROOT_PATH . '/config/loginconfig.php';
require_once ROOT_PATH . '/models/WorksModel.php';
require_once ROOT_PATH . '/models/CarsModel.php';
require_once ROOT_PATH . '/models/ServicesModel.php';
require_once ROOT_PATH . '/models/MastersModel.php';
$uid = $_GET['uid'];

class WorksController{
    protected $model;
    protected $mastersmodel;
    protected $carsmodel;
    protected $servicesmodel;

    function __construct(){
        $this->model = new WorksModel();
        $this->carsmodel = new CarsModel();
        $this->mastersmodel = new MastersModel();
        $this->servicesmodel = new ServicesModel();
    }

    public function listAllWorks(){
        $works = $this->model->getAll();
        $totalCosts = $this->totalCostsNoFilter();
        require_once ROOT_PATH . '/views/works/list.php';
    }

    public function createWork(){
        if($_POST){
            if($this->model->createWork($_POST)){
            ?>
            <script>
                window.location.href = "/?uid=<?= $uid?>&m=works&action=list";
            </script>
            <?php
            } else {
                ?>
                <script>
                    window.location.href="/?uid=<?= $uid?>&m=works&action=list&success=false";
                </script>
                <?php
            }
        } else {
            $masters = $this->mastersmodel->getAll();
            $cars = $this->carsmodel->getAll();
            $services = $this->servicesmodel->getAll();

            require_once ROOT_PATH . '/views/works/create.php';
        }
    }

    public function deleteWork($id){
        if($this->model->deleteWork($id)){
            ?>
            <script>
                window.location.href="/?uid=<?= $uid?>&m=works&action=list&success=true";
            </script>
            <?php
        } else {
            ?>
            <script>
                window.location.href="/?uid=<?= $uid?>&m=works&action=list&success=false";
            </script>
            <?php
        }
    }
    public function editWork($id){
        if($_POST){
            if($this->model->updateWork($id, $_POST)){
                header("Location: ?uid=<?= $uid?>&m=works&action=list&success=true");
            } else {
                header("Location: ?uid=<?= $uid?>&m=works&action=list&success=false");
            }
        } else {
            $current_work = $this->model->getWorkById($id);
            $masters = $this->mastersmodel->getAll();
            $cars = $this->carsmodel->getAll();
            $services = $this->servicesmodel->getAll();
            require_once ROOT_PATH . '/views/works/edit.php';
        }
        
    }

    public function totalCostsDateFilter($date_start, $date_end){
        try {        
            $costs = $this->model->getCostsUniversal($date_start, $date_end);// getCostsFlexibleFunction
            return $costs;
        } catch (PDOException $e) {
            echo "Ошибка: " . $e->getMessage();
        }
    }

    public function totalCostsNoFilter(){
        try {        
            
            $allCosts = $this->model->getCostsUniversal();
            return $allCosts;
        } catch (PDOException $e) {
            echo "Ошибка: " . $e->getMessage();
        }
    }

    public function mostWorkingMasters(){}

    public function filterWorksByDate($date_start, $date_end){
        $works = $this->model->getWorkByDate($date_start, $date_end);
        return $works;
    }
}
?>