<?php
require_once ROOT_PATH . '/models/MastersModel.php';
require_once ROOT_PATH . '/config/loginconfig.php';
$uid = $_GET['uid'];

class MastersController{
    protected $model;

    function __construct(){
        $this->model = new MastersModel();
    }

    public function listAllMasters(){
        try{
            $masters = $this->model->getAll();
            $result = $this->model->getTopMastersByMonth();
            $bestFive = $result['masters'];
            require_once ROOT_PATH . '/views/masters/list.php';
        } catch(PDOException $e){
            error_log("Masters Controller: error: " . $e->getMessage());
        }
    }

    public function createMaster(){
        if($_POST){
            if($this->model->createMaster($_POST)){
            ?>
            <script>
                window.location.href = "/?uid=<?= $uid?>&m=masters&action=list&success=true";
            </script>
            <?php
            } else {
                ?>
                <script>
                    window.location.href="/?uid=<?= $uid?>&m=masters&action=list&success=false";
                </script>
                <?php
            }
        } else {
            require_once ROOT_PATH . '/views/masters/create.php';
        }
    }
    public function deleteMaster($id){
        if($this->model->deleteMaster($id)){
            ?>
            <script>
                window.location.href="/?uid=<?= $uid?>&m=masters&action=list&success=true";
            </script>
            <?php
        } else {
            ?>
            <script>
                window.location.href="/?uid=<?= $uid?>&m=masters&action=list&success=false";
            </script>
            <?php
        }
    }
    public function editMaster($id){
        if($_POST){
            if($this->model->updateMaster($id, $_POST)){
                header("Location: ?uid=<?= $uid?>&m=masters&action=list&success=true");
            } else {
                header("Location: ?uid=<?= $uid?>&m=masters&action=list&success=false");
            }
        } else {
            $current_master = $this->model->getMasterById($id);
            require_once ROOT_PATH . '/views/masters/edit.php';
        }
        
    }
    public function showMaster($id){
        $master = $this->model->getMasterById($id);
        require_once ROOT_PATH . '/views/masters/masterInfo.php';
    }
}
?>