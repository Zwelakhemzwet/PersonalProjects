<?php
require_once ROOT_PATH . '/models/CarsModel.php';
require_once ROOT_PATH . '/config/loginconfig.php';
$uid = $_GET['uid'];

class CarsController{
    private $model;
    function __construct(){
        $this->model = new CarsModel();
    }
    public function listAllCars(){
        $cars = $this->model->getAll();
        require_once ROOT_PATH . '/views/cars/list.php';
    }


    public function createCar(){
        if($_POST){
            if($this->model->createCar($_POST)){
                ?><script>
                    window.location.href="/?uid=<?= $uid?>&m=cars&action=list&success=true";
                </script>
        <?php } else {
        ?>  <script>
                window.location.href="/?uid=<?= $uid?>&m=cars&action=list&success=false";
            </script>
        <?php }
        } else {
            require_once ROOT_PATH . '/views/cars/create.php';
        }
    }

    public function deleteCar($id){
        if($this->model->deleteCar($id)){
            ?>
            <script>
                window.location.href="/?uid=<?= $uid?>&m=cars&action=list&success=true";
            </script>
            <?php
        } else {
            ?>
            <script>
                window.location.href="/?uid=<?= $uid?>&m=cars&action=list&success=false";
            </script>
            <?php
        }
    }

    public function editCar($id){
        if($_POST){
            if($this->model->updateCar($id, $_POST)){
                ?>
                <script>
                    window.location.href="/?uid=<?= $uid?>&m=cars&action=list&success=true";
                </script>
                <?php
            } else {
                ?>
                <script>
                    window.location.href="/?uid=<?= $uid?>&m=cars&action=list&success=false";
                </script>
                <?php
            }
        }
        $current_car = $this->model->getCarById($id);
        require_once ROOT_PATH . "/views/cars/edit.php";
    }
    public function showCar($id){
        $car = $this->model->getCarById($id);
        require_once ROOT_PATH . '/views/cars/carInfo.php';
    }
}

?>