<?php
require_once ROOT_PATH . '/models/ServicesModel.php';
require_once ROOT_PATH . '/config/loginconfig.php';
$uid = $_GET['uid'];


class ServicesController{
    protected $model;

    function __construct(){
        $this->model = new ServicesModel();
    }

    public function listAllServices(){
        $services = $this->model->getAll();
        require_once ROOT_PATH . '/views/services/list.php';
    }

    public function createService(){
        if($_POST){
            if($this->model->createService($_POST)){
            ?>
            <script>
                window.location.href = "/?uid=<?= $uid?>&m=services&action=list";
            </script>
            <?php
            } else {
                ?>
                <script>
                    window.location.href="/?uid=<?= $uid?>&m=services&action=create";
                </script>
                <?php
            }
        } else {
            require_once ROOT_PATH . '/views/services/create.php';
        }
    }
    public function deleteService($id){
        if($this->model->deleteService($id)){
            ?>
            <script>
                window.location.href="/?uid=<?= $uid?>&m=services&action=list&success=true";
            </script>
            <?php
        } else {
            ?>
            <script>
                window.location.href="/?uid=<?= $uid?>&m=services&action=list&success=false";
            </script>
            <?php
        }
    }
    public function editService($id){
        if($_POST){
            if($this->model->updateService($id, $_POST)){
                header("Location: ?uid=<?= $uid?>&m=services&action=list&success=true");
            } else {
                header("Location: ?uid=<?= $uid?>&m=services&action=list&success=false");
            }
        } else {
            $current_service = $this->model->getServiceById($id);
            require_once ROOT_PATH . '/views/services/edit.php';
        }
        
    }

    public function showService($id){
        $service = $this->model->getServiceById($id);
        require_once ROOT_PATH . '/views/services/serviceInfo.php';
    }
}
?>