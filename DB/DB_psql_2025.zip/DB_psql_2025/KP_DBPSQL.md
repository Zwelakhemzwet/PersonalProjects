отсчет по курсовой работе БД

требования

- контролировать целостность данных используя механизм связей. мы это сделали путем создания внешних ключей в таблице работ. это единственная таблица, которая связан с другими таблицами.

- выполнить операции модификации данных в связанных таблицах в рамках транзакции. то есть при модификации данных в таблице работ нужно это сделать в рамках транзакции. например, добавление новую работу

  ```sql
  DO &&
  DECLARE ;
  BEGIN
  	CREATE TEMPORARY TABLE all_cars AS
  	SELECT * FROM cars;
  	
  	FOR (row_ IN all_cars) BEGIN
  		RAISE NOTICE "",row_['id']...
  	END FOR;
  END;
  ```

- создать триггеры для следующих событий

  - не позволяет добавить автомобиль с уже существующим номером
  - не позволяет добавить мастера если их уже больше 10
  - не позволяет дать работу мастеру если он в этот день уже выполнил больше одной работы

  триггер для первого события есть

когда строка удаляется ее присваивают переменной OLD, которую мы можем использовать как обычную строку. получить из него атрибуты таблицы через точку. но это когда мы используем FOR EACH ROW. при этом ясно, что ROW есть переменная OLD. FOR EACH STATEMENT не дает доступ к этим переменным как OLD, NEW.

триггер для добавления автомобился

```sql
CREATE OR REPLACE FUNCTION restrict_duplicate_cars()
RETURNS TRIGGER
AS $$
BEGIN
	IF EXISTS(
		SELECT 1 FROM cars WHERE num = NEW.num AND id != COALESCE(NEW.id, -1)
	) THEN
		RAISE EXCEPTION 'restrict_dupicate_cars: failed to insert car with num %. a car with the same number already exists. Use update instead.', NEW.num;
	END IF;
	RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER on_car_insert_tg
BEFORE INSERT ON cars
FOR EACH ROW
EXECUTE FUNCTION restrict_duplicate_cars();

CREATE TRIGGER on_car_update_tg
BEFORE UPDATE ON cars
FOR EACH ROW
EXECUTE FUNCTION restrict_duplicate_cars();
```



**не позволяем добавить мастера если их уже больше 10**

```sql
CREATE OR REPLACE FUNCTION restrict_extra_masters()
RETURNS TRIGGER
AS $$
DECLARE num_masters INT;
BEGIN
	SELECT COUNT(*) INTO num_masters FROM masters;
	IF num_masters >= 10 THEN
		RAISE EXCEPTION 'restrict_extra_masters: Number of masters already exceeds 10.';
	END IF;
	RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER master_insert_tg
BEFORE INSERT ON masters
FOR EACH ROW
EXECUTE FUNCTION restrict_extra_masters();
```



**триггер для добавления работы мастеру, выполнивших работу на сегодняшний день**

```sql
CREATE OR REPLACE FUNCTION limit_master_work()
RETURNS TRIGGER
AS $$
DECLARE today DATE := CURRENT_DATE;
completed_works INT;
BEGIN
	IF (NEW.date_work < today) THEN
		RAISE EXCEPTION 'limit_master_work: work assignment date is in the past. can only assign works for current date';
	END IF;
	
	SELECT COUNT(*) INTO completed_works FROM works WHERE master_id = NEW.master_id AND date_work = NEW.date_work;
	IF (completed_works >= 1)
	THEN
		RAISE EXCEPTION 'limit_master_work: Failed to assign work to master %. Only one job is allowed for a master per day', NEW.master_id;
	END IF;
	RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER master_assignment_trigger
BEFORE INSERT ON works
FOR EACH ROW
EXECUTE FUNCTION limit_master_work();
```



```
CREATE TABLE users
(id SERIAL PRIMARY KEY,
name TEXT UNIQUE,
role TEXT DEFAULT 'guest',
password_hash TEXT UNIQUE,
user_num TEXT UNIQUE);

CREATE TABLE user_login_stat
(id SERIAL PRIMARY KEY,
user_id INT REFERENCE users (id) ON DELETE RESTRICT ON UPDATE CASCADE,
log_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
log_end TIMESTAMP DEFAULT CURRENT_TIMESTAMP + INTERVAL '30 MINUTES');
```

Общая стоимость обслуживания отечественных и импортных

автомобилей (с возможностью фильтрации по датам оказания

услуги).

```sql

CREATE OR REPLACE PROCEDURE total_service_costs_on_all_cars_dateFilt(
    date_start DATE,
    date_end DATE,
    OUT total_local_costs INT,
    OUT total_foreign_costs INT
)
LANGUAGE plpgsql
AS $$
BEGIN
    SELECT 
        COALESCE(SUM(CASE WHEN c.is_foreign::boolean = false THEN s.cost_our ELSE 0 END), 0),
        COALESCE(SUM(CASE WHEN c.is_foreign::boolean = true THEN s.cost_foreign ELSE 0 END), 0)
    INTO 
        total_local_costs,
        total_foreign_costs
    FROM works w
    LEFT JOIN services s ON s.id = w.service_id
    LEFT JOIN cars c ON c.id = w.car_id
    WHERE w.date_work BETWEEN date_start AND date_end;
END;
$$;

CREATE OR REPLACE PROCEDURE total_service_costs_on_all_cars(
    OUT total_local_costs INT,
    OUT total_foreign_costs INT
)
LANGUAGE plpgsql
AS $$
BEGIN
    SELECT 
        COALESCE(SUM(CASE WHEN c.is_foreign::boolean = false THEN s.cost_our ELSE 0 END), 0),
        COALESCE(SUM(CASE WHEN c.is_foreign::boolean = true THEN s.cost_foreign ELSE 0 END), 0)
    INTO 
        total_local_costs,
        total_foreign_costs
    FROM works w
    LEFT JOIN services s ON s.id = w.service_id
    LEFT JOIN cars c ON c.id = w.car_id;
END;
$$;
```



```sql
DO $$
DECLARE
	date_start DATE := '2025-05-12';
	date_end DATE := '2025-08-30';
	tfc INT;
	tlc INT;
BEGIN
	CALL total_service_costs_on_all_cars_dateFilt(date_start, date_end, tlc, tfc);
	RAISE NOTICE '% - %: total costs on local cars: %, total costs on foreign cars: %', date_start, date_end, tlc, tfc;
END;
$$;
```



```sql
-- exists
CREATE OR REPLACE PROCEDURE total_service_costs_on_all_cars_dateFilt(
    OUT total_local_costs BIGINT,
    OUT total_foreign_costs BIGINT,
    date_start DATE DEFAULT NULL,
    date_end DATE DEFAULT NULL
)
LANGUAGE plpgsql
AS $$
BEGIN
    SELECT 
        COALESCE(SUM(CASE WHEN c.is_foreign::boolean = false THEN s.cost_our ELSE 0 END), 0),
        COALESCE(SUM(CASE WHEN c.is_foreign::boolean = true THEN s.cost_foreign ELSE 0 END), 0)
    INTO 
        total_local_costs,
        total_foreign_costs
    FROM works w
    LEFT JOIN services s ON s.id = w.service_id
    LEFT JOIN cars c ON c.id = w.car_id
    WHERE 
        (date_start IS NOT NULL AND date_end IS NOT NULL AND w.date_work BETWEEN date_start AND date_end)
        OR (date_start IS NOT NULL AND date_end IS NULL AND w.date_work = date_start)
        OR (date_start IS NULL AND date_end IS NOT NULL AND w.date_work <= date_end)
        OR (date_start IS NULL AND date_end IS NULL);
    

    total_local_costs := COALESCE(total_local_costs, 0);
    total_foreign_costs := COALESCE(total_foreign_costs, 0);
END;
$$;
```

```sql
-- exists
CREATE OR REPLACE FUNCTION get_total_costs_by_date_fixed(
    date_start DATE DEFAULT NULL,
    date_end DATE DEFAULT NULL
)
RETURNS TABLE(local_costs BIGINT, foreign_costs BIGINT)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE(SUM(CASE WHEN c.is_foreign::boolean = false THEN s.cost_our ELSE 0 END), 0)::BIGINT,
        COALESCE(SUM(CASE WHEN c.is_foreign::boolean = true THEN s.cost_foreign ELSE 0 END), 0)::BIGINT
    FROM works w
    LEFT JOIN services s ON s.id = w.service_id
    LEFT JOIN cars c ON c.id = w.car_id
    WHERE 
        (date_start IS NOT NULL AND date_end IS NOT NULL AND w.date_work BETWEEN date_start AND date_end)
        OR (date_start IS NOT NULL AND date_end IS NULL AND w.date_work = date_start)
        OR (date_start IS NULL AND date_end IS NOT NULL AND w.date_work <= date_end)
        OR (date_start IS NULL AND date_end IS NULL);
END;
$$;
```



функция для стоимостей без и с фильтрацией

```sql
CREATE OR REPLACE FUNCTION get_total_costs_universal(
    date_start DATE DEFAULT NULL,
    date_end DATE DEFAULT NULL
)
RETURNS TABLE(local_costs BIGINT, foreign_costs BIGINT)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE(SUM(CASE WHEN c.is_foreign::boolean = false THEN s.cost_our ELSE 0 END), 0)::BIGINT,
        COALESCE(SUM(CASE WHEN c.is_foreign::boolean = true THEN s.cost_foreign ELSE 0 END), 0)::BIGINT
    FROM works w
    LEFT JOIN services s ON s.id = w.service_id
    LEFT JOIN cars c ON c.id = w.car_id
    WHERE 
        (date_start IS NOT NULL AND date_end IS NOT NULL AND w.date_work BETWEEN date_start AND date_end)
        OR (date_start IS NOT NULL AND date_end IS NULL AND w.date_work = date_start)
        OR (date_start IS NULL AND date_end IS NOT NULL AND w.date_work <= date_end)
        OR (date_start IS NULL AND date_end IS NULL);
END;
$$;
```





show best five masters

```sql
CREATE OR REPLACE FUNCTION get_top_masters_by_unique_cars(
    month_year DATE DEFAULT NULL
)
RETURNS TABLE(
    master_id INTEGER,
    master_name TEXT,
    unique_cars_count BIGINT,
    total_works_count BIGINT,
    month_period TEXT
)
LANGUAGE plpgsql
AS $$
DECLARE
    target_month INTEGER;
    target_year INTEGER;
BEGIN
    IF month_year IS NULL THEN
        target_month := EXTRACT(MONTH FROM CURRENT_DATE);
        target_year := EXTRACT(YEAR FROM CURRENT_DATE);
    ELSE
        target_month := EXTRACT(MONTH FROM month_year);
        target_year := EXTRACT(YEAR FROM month_year);
    END IF;
    
    RETURN QUERY
    SELECT 
        m.id as master_id,
        m.name as master_name,
        COUNT(DISTINCT w.car_id) as unique_cars_count,
        COUNT(*) as total_works_count,
        TO_CHAR(month_year, 'YYYY-MM') as month_period
    FROM works w
    INNER JOIN masters m ON m.id = w.master_id
    WHERE 
        EXTRACT(MONTH FROM w.date_work) = target_month
        AND EXTRACT(YEAR FROM w.date_work) = target_year
    GROUP BY m.id, m.name
    ORDER BY unique_cars_count DESC, total_works_count DESC
    LIMIT 5;
END;
$$;
```
