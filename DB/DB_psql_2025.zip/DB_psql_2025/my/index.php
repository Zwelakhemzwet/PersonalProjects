<?php
define('ROOT_PATH', __DIR__ . '/..');
define('PAGE_ROOT', '/DB_psql_2025');
//require_once ROOT_PATH . '/views/layout/scripts.php';

spl_autoload_register(function ($class) {
    if (file_exists(ROOT_PATH . '/controllers/' . $class . '.php')) {
        require_once ROOT_PATH .'/controllers/' . $class . '.php';
    } elseif (file_exists(ROOT_PATH . '/models/' . $class . '.php')) {
        require_once ROOT_PATH . '/models/' . $class . '.php';
    }
});
$admincontroller = new AdminController();
$model = $_GET['m'];
$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? null;

switch($model){
    // case "register":
    //     $admincontroller->userRegistration();
    //     break;
    // case "login":
    //     $access = $admincontroller->userLogin(null);
    //     break;
    case "cars":
        $carcontroller = new CarsController();
        switch($action){
            case 'list':
                $carcontroller->listAllCars();
                break;
            case 'edit':
                if($id){
                    $carcontroller->editCar($id);
                }
                break;
            case 'delete':
                if($id){
                    $carcontroller->deleteCar($id);
                }
                break;
            case 'create':
                $carcontroller->createCar();
                break;
            case 'info':
                if($id){
                    $carcontroller->showCar($id);
                }
                break;
            default:
                $carcontroller->listAllCars();
                break;
        }
        break;
    case "works":
        $workscontroller = new WorksController();
        switch($action){
            case 'list':
                $workscontroller->listAllWorks();
                break;
            case 'edit':
                if($id){
                    $workscontroller->editWork($id);
                }
                break;
            
            case 'create':
                $workscontroller->createWork();
                break;
            case 'delete':
                if($id){
                    $workscontroller->deleteWork($id);
                }
                break;
            case 'date_filter':
                $costs = [];
                $works = [];
                if(isset($_GET['ds']) && !empty($_GET['ds'])){
                    // все работы в эти даты
                    $works = $workscontroller->filterWorksByDate($_GET['ds'], $_GET['de'] ?? null);

                    // стоимости в эти даты
                    $costs = $workscontroller->totalCostsDateFilter($_GET['ds'], $_GET['de'] ?? null);
                    // стоимости без фильтрации
                    $totalcosts = $workscontroller->totalCostsNoFilter();

                    header("Content-Type: application/json");
                    echo json_encode(['works' => $works, 'costs' => $costs, 'totalCosts' => $totalcosts]);
                } else {
                    $totalcosts = $workscontroller->totalCostsNoFilter();
                }
                break;
            default:
                $workscontroller->listAllWorks();
                break;
        }
        break;
    case 'masters':
        $masterscontroller = new MastersController();
        switch($action){
            case 'list':
                $masterscontroller->listAllMasters();
                break;
            case 'edit':
                if($id){
                    $masterscontroller->editMaster($id);
                }
                break;
            
            case 'create':
                $masterscontroller->createMaster();
                break;
            case 'delete':
                if($id){
                    $masterscontroller->deleteMaster($id);
                }
                break;
            default:
                $masterscontroller->listAllMasters();
                break;
        }
        break;
    case 'services':
        $servicescontroller = new ServicesController();
        switch($action){
            case 'list':
                $servicescontroller->listAllServices();
                break;
            case 'edit':
                if($id){
                    $servicescontroller->editService($id);
                }
                break;
            
            case 'create':
                $servicescontroller->createService();
                break;
            case 'delete':
                if($id){
                    $servicescontroller->deleteService($id);
                }
                break;
            case 'info':
                if($id){
                    $servicescontroller->showService($id);
                }
                break;
            default:
                $servicescontroller->listAllServices();
                break;
        }
        break;
    default:
        
        $admincontroller->dashboard();
        break;
}

?>